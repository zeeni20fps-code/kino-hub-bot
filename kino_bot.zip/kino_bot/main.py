if __name__ == "__main__":
    print("Bot ishga tushdi")
    app.run_polling()